// searchbar
let header = document.querySelector('.header'),
	searchBtn = document.querySelector('.searchBtn'),
	navBtn = document.querySelector('.navBtn'),
	navLinks = document.querySelector('.navLinks');

searchBtn.addEventListener("click", () => {
	header.classList.toggle('openSearch');

	if (header.classList.contains('openSearch')) {
		searchBtn.classList.replace('fa-search', 'fa-times');
	} else {
		searchBtn.classList.replace('fa-times', 'fa-search');
	}
	document.addEventListener('click', (e) => {
		let searchbox=document.querySelector('.searcharea');
		
		let clicked = searchBtn.contains(e.target) || searchbox.contains(e.target);
		if (!clicked) {
			header.classList.remove('openSearch');
			searchBtn.classList.replace('fa-times', 'fa-search');
		}
	})
})


// typing text
let text = document.querySelector('.typingText');
let textLoad = () => {
	setTimeout(() => {
		text.textContent = 'Begginer';
	}, 0);
	setTimeout(() => {
		text.textContent = 'designer';
	}, 5000);
	setTimeout(() => {
		text.textContent = 'developer';
	}, 10000);
}

textLoad();
setInterval(textLoad, 15000);


// Progress Bar
let percent = document.querySelectorAll('.percent'),
	progress = document.querySelectorAll('.skills .progress');

let progressStart = 0;

setInterval(() => {
	progressStart++;

	if (progressStart <= 90) {
		percent[0].textContent = `${progressStart}%`;
		progress[0].style.width = `${progressStart}%`;
	}
	if (progressStart <= 30) {
		percent[1].textContent = `${progressStart}%`;
		progress[1].style.width = `${progressStart}%`;
	}
	if (progressStart <= 80) {
		percent[2].textContent = `${progressStart}%`;
		progress[2].style.width = `${progressStart}%`;
	}
	if (progressStart <= 50) {
		percent[3].textContent = `${progressStart}%`;
		progress[3].style.width = `${progressStart}%`;
	}
	if (progressStart <= 20) {
		percent[4].textContent = `${progressStart}%`;
		progress[4].style.width = `${progressStart}%`;
	}
}, 100);


// Slider
let slides=document.querySelectorAll('.slide'),
 prevBtn=document.querySelector('.prev'),
 nextBtn=document.querySelector('.next');
 
 let slideIndex=0;
 
 function slide(x){
 	slideIndex= slideIndex+x;
 slider(slideIndex);
 	
 }
 
 function slider(reciver){
 	for(index of slides){
 	index.style.display ='none';
 	}
 	if(reciver >=slides.length){
 		slideIndex = 0;
 		reciver = 0;
 	}
 	else if(reciver<0){
 		slideIndex=slides.length-1;
 		reciver=slides.length-1;
 	}
 	
 	slides[reciver].style.display ='block';
 }
 
 slider(slideIndex);
 
 
 
 
// Form validation

let form = document.querySelector('form'),
 nameField = document.querySelector('.name-field'),
 nameInput = document.querySelector('.formname'),
 
 emailField = document.querySelector('.email-field'),
 emailInput = document.querySelector('.email'),
 
 passField = document.querySelector('.password-field'),
 passInput = document.querySelector('.password'),
 
 confirmPassField = document.querySelector('.confirmPass-field'),
 confirmPassInput = document.querySelector('.confirmPass'),
 
 eyeIcon = document.querySelectorAll('.showPassword'),
 button = document.querySelector('.submit-button');

eyeIcon.forEach((eyeIcons)=>{
	let pInput=eyeIcons.parentElement.querySelector('input');

	eyeIcons.addEventListener('click',()=>{
		if (pInput.type === 'password') {
			pInput.type='text';
			eyeIcons.classList.replace('fa-eye-slash','fa-eye');
		}else{
			pInput.type='password';
			eyeIcons.classList.replace('fa-eye','fa-eye-slash');
		}
	});
	
});
function nameCheck(){
	
	if (nameInput.value.length < 5) {
		nameField.classList.add('invalid');
	}
	else{
		nameField.classList.remove('invalid');
	};
};
function emailCheck(){
	const emailPattern = /^[^ ]+@+[^ ]+ \.[a-z]{2,3}$/;

	if (!emailInput.value.match(emailPattern)) {
	 emailField.classList.add('invalid');
	}else{
		emailField.classList.remove('invalid');
	}
};
function passCheck(){
	const passPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
 if (!passInput.value.match(passPattern)) {
 	passField.classList.add('invalid');
 }
	else{
 	passField.classList.remove('invalid');
	}
};
function confirmPassCheck(){
	if (confirmPassInput.value !== passInput.value) {
		confirmPassField.classList.add('invalid');
	}else{
		confirmPassField.classList.remove('invalid');
		
	}
};
form.addEventListener('submit',(e)=>{
	e.preventDefault();
	nameCheck();
	emailCheck();
	passCheck();
	confirmPassCheck();
	
	nameInput.addEventListener('keyup',nameCheck);
	emailInput.addEventListener('keyup',emailCheck);
	passInput.addEventListener('keyup',passCheck);
	confirmPassInput.addEventListener('keyup',confirmPassCheck);
});
